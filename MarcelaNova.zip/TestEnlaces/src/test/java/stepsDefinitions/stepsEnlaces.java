package stepsDefinitions;
import EnlacesSteps.enlacesSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;


public class stepsEnlaces {
	
	@Steps
	enlacesSteps enlacesSteps;
	
	@Given("^Abrir la sección servicios$")
	public void abrir_la_sección_servicios() {
		
		enlacesSteps.pasos();
				
	}

	@When("^Entrar a los enlaces$")
	public void entrar_a_los_enlaces() {
		
	}

	@Then("^verificar contenido$")
	public void verificar_contenido() {
		
	}
}




