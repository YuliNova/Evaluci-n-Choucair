package pageObjets;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;



@DefaultUrl("https://www.choucairtesting.com/")

public class pageObjets extends PageObject {
	
	@FindBy(xpath="(//H2[@class='maintitle'][text()='Pruebas de software centradas en su negocio'][text()='Pruebas de software centradas en su negocio'])[2]")
	public WebElementFacade Header;

	public  void Titulo (){
		Header.click();
	}

	
	

}


