
package EnlacesSteps;

import net.thucydides.core.annotations.Step;
import pageObjets.pageObjets;


public class enlacesSteps {
	pageObjets pageObjets;
	
	@Step
	public void pasos() {
		
	pageObjets.open();
	//pageObjets.Titulo();
	
	}
}
